<?php
$plainCredentials = '***:***';
$appid = '***';

$baseUrl = 'https://api.agora.io/dev';

